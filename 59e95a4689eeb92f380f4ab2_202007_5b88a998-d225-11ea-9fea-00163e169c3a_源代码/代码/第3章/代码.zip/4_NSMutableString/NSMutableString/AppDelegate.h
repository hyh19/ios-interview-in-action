//
//  AppDelegate.h
//  NSMutableString
//
//  Created by jaki on 2019/9/22.
//  Copyright © 2019 jaki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic ,strong) UIWindow *window;

@end

