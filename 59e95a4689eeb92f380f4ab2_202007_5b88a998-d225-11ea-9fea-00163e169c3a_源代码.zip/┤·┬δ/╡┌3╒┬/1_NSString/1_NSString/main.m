//
//  main.m
//  1_NSString
//
//  Created by jaki on 2019/9/18.
//  Copyright © 2019 jaki. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
