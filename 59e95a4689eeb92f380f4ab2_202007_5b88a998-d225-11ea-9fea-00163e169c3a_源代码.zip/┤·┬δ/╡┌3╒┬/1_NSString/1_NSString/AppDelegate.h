//
//  AppDelegate.h
//  1_NSString
//
//  Created by jaki on 2019/9/18.
//  Copyright © 2019 jaki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

