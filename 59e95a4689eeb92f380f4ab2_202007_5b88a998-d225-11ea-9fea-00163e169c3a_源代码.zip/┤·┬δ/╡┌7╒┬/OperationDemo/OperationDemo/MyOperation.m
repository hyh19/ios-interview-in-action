//
//  MyOperation.m
//  OperationDemo
//
//  Created by 珲少 on 2020/2/1.
//  Copyright © 2020 jaki. All rights reserved.
//

#import "MyOperation.h"

@implementation MyOperation

- (void)main {
    NSLog(@"自定义操作");
}

@end
