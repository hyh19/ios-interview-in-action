//
//  MyOperation.h
//  OperationDemo
//
//  Created by 珲少 on 2020/2/1.
//  Copyright © 2020 jaki. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyOperation : NSOperation

@end

NS_ASSUME_NONNULL_END
