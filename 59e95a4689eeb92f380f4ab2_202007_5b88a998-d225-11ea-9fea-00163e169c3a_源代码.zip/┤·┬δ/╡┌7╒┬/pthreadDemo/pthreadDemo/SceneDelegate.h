//
//  SceneDelegate.h
//  pthreadDemo
//
//  Created by 珲少 on 2020/1/19.
//  Copyright © 2020 jaki. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

