//
//  MyThread.h
//  NSThreadDemo
//
//  Created by 珲少 on 2020/1/29.
//  Copyright © 2020 jaki. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyThread : NSThread

@end

NS_ASSUME_NONNULL_END
